package com.hesn.privatebrowser;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private ProgressBar progress;
    private static final String HOME = "https://html.duckduckgo.com/html/";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.web); address = findViewById(R.id.address); progress = findViewById(R.id.progress);
        configurePrivacy();
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (!url.startsWith("https://")) { Toast.makeText(MainActivity.this, "تم منع اتصال غير مشفر", Toast.LENGTH_SHORT).show(); return true; }
                return false;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { address.setText(url); }
            @Override public void onPageFinished(WebView v, String url) { v.clearHistory(); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int n) { progress.setProgress(n); progress.setVisibility(n == 100 ? ProgressBar.GONE : ProgressBar.VISIBLE); }
            @Override public void onPermissionRequest(PermissionRequest r) { r.deny(); }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) { cb.invoke(origin, false, false); }
        });
        Button go = findViewById(R.id.go); go.setOnClickListener(v -> navigate());
        address.setOnEditorActionListener((v,id,e) -> { navigate(); return true; });
        findViewById(R.id.back).setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        findViewById(R.id.home).setOnClickListener(v -> web.loadUrl(HOME));
        findViewById(R.id.reload).setOnClickListener(v -> web.reload());
        findViewById(R.id.clear).setOnClickListener(v -> { clearAll(); web.loadUrl(HOME); Toast.makeText(this,"تم محو الجلسة",Toast.LENGTH_SHORT).show(); });
        web.loadUrl(HOME);
    }

    private void configurePrivacy() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setDatabaseEnabled(false);
        s.setGeolocationEnabled(false);
        s.setSaveFormData(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, false);
        WebView.setWebContentsDebuggingEnabled(false);
    }

    private void navigate() {
        String q = address.getText().toString().trim();
        if (q.isEmpty()) return;
        if (q.startsWith("http://")) { Toast.makeText(this,"HTTP غير مسموح",Toast.LENGTH_SHORT).show(); return; }
        if (q.startsWith("https://")) web.loadUrl(q);
        else if (q.contains(".") && !q.contains(" ")) web.loadUrl("https://" + q);
        else web.loadUrl(HOME + "?q=" + URLEncoder.encode(q, StandardCharsets.UTF_8));
    }

    private void clearAll() {
        web.stopLoading(); web.clearHistory(); web.clearCache(true); web.clearFormData(); web.clearSslPreferences();
        CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
        getCacheDir().delete();
    }

    @Override protected void onStop() { clearAll(); super.onStop(); }
    @Override protected void onDestroy() { clearAll(); web.loadUrl("about:blank"); web.removeAllViews(); web.destroy(); super.onDestroy(); }
    @Override public boolean onKeyDown(int key, KeyEvent event) { if (key == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true; } return super.onKeyDown(key,event); }
}
