# متصفح الحصن
مشروع Android أصلي بلا إعلانات أو تحليلات أو تبعيات خارجية داخل التطبيق.

## البناء
افتح المجلد في Android Studio، دع Gradle يتزامن، ثم اختر Build > Build APK(s).
الـ APK التجريبي سيظهر عادة داخل app/build/outputs/apk/debug/.

## ملاحظة
التطبيق يمحو بيانات WebView عند الانتقال للخلفية وعند الإتلاف، ولذلك قد تُسجّل خروجك المواقع فورًا. JavaScript مفعّل للتوافق، والتخزين المحلي معطّل.

## البناء الآلي عبر GitHub
المشروع يحتوي على `.github/workflows/build-apk.yml`. بعد رفعه إلى مستودع، افتح Actions ثم Build APK ثم Run workflow. سيظهر الملف باسم HesnPrivateBrowser-debug-apk ضمن Artifacts.
---

**تصميم وبرمجة: [iegy.net](https://iegy.net)**

