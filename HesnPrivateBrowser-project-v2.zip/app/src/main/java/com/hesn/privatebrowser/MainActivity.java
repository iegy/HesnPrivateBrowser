package com.hesn.privatebrowser;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private ProgressBar progress;
    private View startPanel, toolbar;
    private Button jsButton;
    private boolean javaScriptEnabled = false;
    private static final String SEARCH = "https://html.duckduckgo.com/html/?q=";
    private static final String PRIVATE_UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(12, bars.top, 12, bars.bottom);
            return insets;
        });
        web = findViewById(R.id.web); address = findViewById(R.id.address); progress = findViewById(R.id.progress);
        startPanel = findViewById(R.id.startPanel); toolbar = findViewById(R.id.toolbar); jsButton = findViewById(R.id.js);
        configurePrivacy();
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (!url.startsWith("https://")) { toast("تم منع اتصال غير مشفر"); return true; }
                return false;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { address.setText(url); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int n) { progress.setProgress(n); progress.setVisibility(n == 100 ? View.GONE : View.VISIBLE); }
            @Override public void onPermissionRequest(PermissionRequest r) { r.deny(); }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) { cb.invoke(origin, false, false); }
        });
        findViewById(R.id.go).setOnClickListener(v -> navigate());
        address.setOnEditorActionListener((v,id,e) -> { navigate(); return true; });
        findViewById(R.id.back).setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); else showStart(); });
        findViewById(R.id.home).setOnClickListener(v -> showStart());
        findViewById(R.id.reload).setOnClickListener(v -> web.reload());
        jsButton.setOnClickListener(v -> toggleJavaScript());
        findViewById(R.id.clear).setOnClickListener(v -> { clearAll(); showStart(); toast("تم محو الجلسة"); });
        showStart();
    }

    private void configurePrivacy() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setDomStorageEnabled(false); s.setDatabaseEnabled(false); s.setGeolocationEnabled(false); s.setSaveFormData(false);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true); s.setUserAgentString(PRIVATE_UA); s.setSafeBrowsingEnabled(true);
        CookieManager cm = CookieManager.getInstance(); cm.setAcceptCookie(false); cm.setAcceptThirdPartyCookies(web, false);
        WebView.setWebContentsDebuggingEnabled(false);
    }

    private void navigate() {
        String q = address.getText().toString().trim(); if (q.isEmpty()) return;
        String url;
        if (q.startsWith("http://")) { toast("HTTP غير مسموح"); return; }
        else if (q.startsWith("https://")) url=q;
        else if (q.contains(".") && !q.contains(" ")) url="https://"+q;
        else url=SEARCH+URLEncoder.encode(q, StandardCharsets.UTF_8);
        startPanel.setVisibility(View.GONE); web.setVisibility(View.VISIBLE); toolbar.setVisibility(View.VISIBLE);
        Map<String,String> h=new HashMap<>(); h.put("DNT","1"); h.put("Sec-GPC","1");
        web.loadUrl(url,h);
    }

    private void showStart() {
        web.stopLoading(); web.loadUrl("about:blank"); clearAll(); address.setText("");
        web.setVisibility(View.GONE); toolbar.setVisibility(View.GONE); progress.setVisibility(View.GONE); startPanel.setVisibility(View.VISIBLE);
        address.requestFocus();
    }

    private void toggleJavaScript() {
        javaScriptEnabled=!javaScriptEnabled; web.getSettings().setJavaScriptEnabled(javaScriptEnabled);
        jsButton.setText(javaScriptEnabled ? "JS: مفتوح" : "JS: مغلق");
        toast(javaScriptEnabled ? "JavaScript مفتوح لهذا التصفح وقد يزيد البصمة" : "JavaScript مغلق");
        web.reload();
    }

    private void clearAll() {
        web.stopLoading(); web.clearHistory(); web.clearCache(true); web.clearFormData(); web.clearSslPreferences();
        CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override protected void onStop() { clearAll(); super.onStop(); }
    @Override protected void onDestroy() { clearAll(); web.loadUrl("about:blank"); web.removeAllViews(); web.destroy(); super.onDestroy(); }
    @Override public boolean onKeyDown(int key, KeyEvent event) { if (key==KeyEvent.KEYCODE_BACK) { if (web.getVisibility()==View.VISIBLE && web.canGoBack()) web.goBack(); else showStart(); return true; } return super.onKeyDown(key,event); }
}